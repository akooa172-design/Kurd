import React, { useState } from 'react';
import { addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { AtSign, Film, Hash, Image as ImageIcon, Link2, Music2, Upload, X } from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { translations } from '../i18n';
import { Language, Post, UserProfile } from '../types';
import { compressImageFile, fileToDataUrl, STARTER_REELS } from '../utils/media';

interface CreatePostModalProps {
  currentUser: UserProfile;
  friendsList: UserProfile[];
  lang: Language;
  onClose: () => void;
  onPublished: () => void;
  onGuestPostCreated?: (post: Post) => void;
}

const SUGGESTED_HASHTAGS = ['#کوردستان', '#گەشت', '#مۆسیقا', '#یاری', '#تیکتۆک'];

export const CreatePostModal: React.FC<CreatePostModalProps> = ({
  currentUser,
  friendsList,
  lang,
  onClose,
  onPublished,
  onGuestPostCreated,
}) => {
  const t = translations[lang];
  const [mediaType, setMediaType] = useState<'image' | 'video'>('image');
  const [mediaUrl, setMediaUrl] = useState<string>(STARTER_REELS[0].mediaUrl);
  const [caption, setCaption] = useState('');
  const [musicTitle, setMusicTitle] = useState('');
  const [taggedUsers, setTaggedUsers] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState('');
  const [visibility, setVisibility] = useState<'public' | 'friends'>('public');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setError(null);

    try {
      if (file.type.startsWith('video/')) {
        if (file.size > 450 * 1024) {
          setError(
            lang === 'ku'
              ? 'قەبارەی ڤیدیۆکە زۆر گەورەیە (زۆرترین ٤٥٠ کیلۆبایت). لینکی ڤیدیۆ دابنێ یان وێنە هەڵبژێرە.'
              : 'Video file is too large for direct upload (max 450KB). Paste a video URL or upload a photo.'
          );
          return;
        }
        const dataUrl = await fileToDataUrl(file);
        setMediaType('video');
        setMediaUrl(dataUrl);
      } else if (file.type.startsWith('image/')) {
        const compressed = await compressImageFile(file, 720, 0.78);
        setMediaType('image');
        setMediaUrl(compressed);
      } else {
        setError('تکایە وێنەیەک یان ڤیدیۆیەک هەڵبژێرە.');
      }
    } catch {
      setError('ناتوانرێت ئەم فایلە بکرێتەوە.');
    }
  };

  const handleAddHashtag = (tag: string) => {
    if (caption.includes(tag)) return;
    setCaption((prev) => (prev.trim() ? `${prev.trim()} ${tag}` : tag));
  };

  const handleToggleTagUser = (username: string) => {
    const clean = username.trim().toLowerCase().replace(/^@/, '');
    if (!clean) return;
    setTaggedUsers((prev) => {
      if (prev.includes(clean)) return prev.filter((u) => u !== clean);
      if (prev.length >= 10) return prev;
      return [...prev, clean];
    });
  };

  const handleAddManualTag = () => {
    const clean = tagInput
      .trim()
      .toLowerCase()
      .replace(/^@/, '')
      .replace(/[^a-z0-9_]/g, '');
    if (clean.length >= 2 && !taggedUsers.includes(clean) && taggedUsers.length < 10) {
      setTaggedUsers((prev) => [...prev, clean]);
    }
    setTagInput('');
  };

  const handlePublish = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mediaUrl.trim() || submitting) return;
    if (mediaUrl.length > 580000) {
      setError('قەبارەی فایلەکە زۆر گەورەیە. وێنەیەکی بچووکتر یان لینک دابنێ.');
      return;
    }

    setSubmitting(true);
    setError(null);
    if (currentUser.isGuest) {
      if (onGuestPostCreated) {
        onGuestPostCreated({
          id: `guest_post_${Date.now()}`,
          authorId: currentUser.uid,
          authorName: currentUser.displayName,
          authorUsername: currentUser.username,
          authorPhoto: currentUser.photoURL || '',
          caption: caption.trim().slice(0, 500),
          mediaType,
          mediaUrl: mediaUrl.trim(),
          musicTitle:
            musicTitle.trim().slice(0, 120) ||
            `دەنگی ڕەسەن — ${currentUser.displayName}`,
          taggedUsers,
          likesCount: 0,
          commentsCount: 0,
          visibility,
        });
      }
      onPublished();
      onClose();
      setSubmitting(false);
      return;
    }
    try {
      await addDoc(collection(db, 'posts'), {
        authorId: currentUser.uid,
        authorName: currentUser.displayName,
        authorUsername: currentUser.username,
        authorPhoto: currentUser.photoURL || '',
        caption: caption.trim().slice(0, 500),
        mediaType,
        mediaUrl: mediaUrl.trim(),
        musicTitle:
          musicTitle.trim().slice(0, 120) || `دەنگی ڕەسەن — ${currentUser.displayName}`,
        taggedUsers,
        likesCount: 0,
        commentsCount: 0,
        visibility,
        createdAt: serverTimestamp(),
      });
      onPublished();
      onClose();
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'posts');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="w-full sm:max-w-2xl bg-zinc-900 border border-zinc-800 rounded-t-3xl sm:rounded-2xl max-h-[92vh] flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800">
          <h2 className="font-display text-lg font-bold text-white">{t.newPostTitle}</h2>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[40px] min-w-[40px] rounded-lg text-zinc-400 hover:text-white flex items-center justify-center cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handlePublish} className="flex-1 overflow-y-auto p-6">
          <div className="grid grid-cols-1 sm:grid-cols-12 gap-6 items-start">
            {/* Left 9:16 Live Preview */}
            <div className="sm:col-span-5">
              <div className="aspect-[9/16] w-full max-w-[220px] mx-auto rounded-2xl overflow-hidden bg-zinc-950 border border-zinc-800 relative">
                {mediaType === 'video' ? (
                  <video
                    src={mediaUrl}
                    autoPlay
                    loop
                    muted
                    playsInline
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <img
                    src={mediaUrl}
                    alt="Preview"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                )}
                <div className="absolute inset-x-0 bottom-0 p-3 bg-gradient-to-t from-black/85 to-transparent text-white">
                  <p className="text-xs font-semibold">@{currentUser.username}</p>
                  <p className="text-[11px] text-zinc-200 line-clamp-2 mt-0.5">
                    {caption || t.captionPlaceholder}
                  </p>
                  {taggedUsers.length > 0 && (
                    <p className="text-[10px] text-amber-400 mt-1 truncate">
                      {taggedUsers.map((u) => `@${u}`).join(' · ')}
                    </p>
                  )}
                </div>
              </div>
            </div>

            {/* Right Controls */}
            <div className="sm:col-span-7 space-y-4">
              {error && (
                <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-xs text-red-300">
                  {error}
                </div>
              )}

              {/* Upload Button */}
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-2">
                  {t.uploadMedia}
                </label>
                <label className="min-h-[48px] px-4 py-3 rounded-xl bg-zinc-950 border border-dashed border-zinc-700 hover:border-amber-500 text-zinc-200 text-sm font-medium flex items-center justify-center gap-2 cursor-pointer transition-colors">
                  <Upload className="w-4 h-4 text-amber-400" />
                  <span>{t.uploadMedia}</span>
                  <input
                    type="file"
                    accept="image/*,video/*"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                </label>
              </div>

              {/* Or Paste URL */}
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                  {t.orPasteUrl}
                </label>
                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <Link2 className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={mediaUrl.startsWith('data:') ? '' : mediaUrl}
                      onChange={(e) => {
                        const val = e.target.value;
                        setMediaUrl(val);
                        if (val.match(/\.(mp4|webm|mov)(\?|$)/i)) {
                          setMediaType('video');
                        } else {
                          setMediaType('image');
                        }
                      }}
                      placeholder="https://..."
                      className="w-full min-h-[44px] pl-10 pr-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:border-amber-500"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      setMediaType((prev) => (prev === 'image' ? 'video' : 'image'))
                    }
                    className="min-h-[44px] px-3 py-2 rounded-xl bg-zinc-800 text-xs font-semibold text-zinc-200 flex items-center gap-1.5 hover:bg-zinc-700 cursor-pointer shrink-0"
                  >
                    {mediaType === 'video' ? (
                      <>
                        <Film className="w-3.5 h-3.5 text-amber-400" />
                        <span>ڤیدیۆ</span>
                      </>
                    ) : (
                      <>
                        <ImageIcon className="w-3.5 h-3.5 text-amber-400" />
                        <span>وێنە</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Caption / Video Bio + Hashtags */}
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                  {lang === 'ku' ? 'کەپشن و بایۆی ڤیدیۆ (#هاشتاگ)' : t.captionLabel}
                </label>
                <textarea
                  rows={2}
                  value={caption}
                  onChange={(e) => setCaption(e.target.value)}
                  placeholder={t.captionPlaceholder}
                  maxLength={500}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:border-amber-500 resize-none"
                />
                <div className="mt-2 flex flex-wrap items-center gap-1.5">
                  {SUGGESTED_HASHTAGS.map((tag) => (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => handleAddHashtag(tag)}
                      className="px-2.5 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-amber-400 flex items-center gap-1 cursor-pointer"
                    >
                      <Hash className="w-3 h-3" />
                      <span>{tag.replace('#', '')}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Tag Friends */}
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                  {lang === 'ku' ? 'تاگکردنی هاوڕێکان (@)' : 'Tag Friends (@)'}
                </label>
                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <AtSign className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={tagInput}
                      onChange={(e) => setTagInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleAddManualTag();
                        }
                      }}
                      placeholder={lang === 'ku' ? 'ناوی هاوڕێ بنووسە...' : 'Type username...'}
                      className="w-full min-h-[42px] pl-10 pr-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:border-amber-500"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={handleAddManualTag}
                    className="min-h-[42px] px-4 py-2 rounded-xl bg-zinc-800 text-xs font-semibold text-white hover:bg-zinc-700 cursor-pointer shrink-0"
                  >
                    {lang === 'ku' ? 'تاگ بکە' : 'Tag'}
                  </button>
                </div>

                {friendsList.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {friendsList.map((f) => {
                      const active = taggedUsers.includes(f.username);
                      return (
                        <button
                          key={f.uid}
                          type="button"
                          onClick={() => handleToggleTagUser(f.username)}
                          className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition-colors cursor-pointer ${
                            active
                              ? 'bg-amber-500 text-zinc-950 border-amber-400'
                              : 'bg-zinc-950 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                          }`}
                        >
                          @{f.username}
                        </button>
                      );
                    })}
                  </div>
                )}

                {taggedUsers.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {taggedUsers.map((u) => (
                      <button
                        key={u}
                        type="button"
                        onClick={() => handleToggleTagUser(u)}
                        className="px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                      >
                        <span>@{u}</span>
                        <X className="w-3 h-3" />
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Music / Sound */}
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                  {t.musicLabel}
                </label>
                <div className="relative">
                  <Music2 className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={musicTitle}
                    onChange={(e) => setMusicTitle(e.target.value)}
                    placeholder={t.musicPlaceholder}
                    maxLength={120}
                    className="w-full min-h-[44px] pl-10 pr-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              {/* Visibility */}
              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setVisibility('public')}
                  className={`flex-1 min-h-[40px] px-3 py-2 rounded-xl text-xs font-semibold border transition-colors cursor-pointer ${
                    visibility === 'public'
                      ? 'bg-white text-zinc-950 border-white'
                      : 'bg-zinc-950 text-zinc-400 border-zinc-800 hover:text-white'
                  }`}
                >
                  {t.forYou} (گشتی)
                </button>
                <button
                  type="button"
                  onClick={() => setVisibility('friends')}
                  className={`flex-1 min-h-[40px] px-3 py-2 rounded-xl text-xs font-semibold border transition-colors cursor-pointer ${
                    visibility === 'friends'
                      ? 'bg-white text-zinc-950 border-white'
                      : 'bg-zinc-950 text-zinc-400 border-zinc-800 hover:text-white'
                  }`}
                >
                  {t.friendsOnly}
                </button>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-zinc-800 flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="min-h-[44px] px-5 py-2.5 rounded-xl bg-zinc-800 text-zinc-200 text-sm font-semibold hover:bg-zinc-700 transition-colors cursor-pointer"
            >
              پاشگەزبوونەوە
            </button>
            <button
              type="submit"
              disabled={submitting || !mediaUrl.trim()}
              className="min-h-[44px] px-6 py-2.5 rounded-xl bg-amber-500 text-zinc-950 text-sm font-bold hover:bg-amber-400 disabled:opacity-50 transition-colors cursor-pointer"
            >
              {submitting ? t.publishing : t.publishPost}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
