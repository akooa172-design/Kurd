import React, { useState } from 'react';
import { signOut } from 'firebase/auth';
import { doc, serverTimestamp, updateDoc } from 'firebase/firestore';
import { Camera, Check, Download, Film, LogOut, Plus } from 'lucide-react';
import { auth, db, handleFirestoreError, OperationType } from '../firebase';
import { translations } from '../i18n';
import { Language, Post, UserProfile } from '../types';
import { compressImageFile } from '../utils/media';
import { formatFollowersCount, VerifiedBadge } from './VerifiedBadge';

interface ProfileViewProps {
  currentUser: UserProfile;
  myPosts: Post[];
  friendsCount: number;
  lang: Language;
  onToggleLang: () => void;
  onOpenCreatePost: () => void;
  onGuestSignOut: () => void;
  onUpdateGuestProfile: (updates: Partial<UserProfile>) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  currentUser,
  myPosts,
  friendsCount,
  lang,
  onToggleLang,
  onOpenCreatePost,
  onGuestSignOut,
  onUpdateGuestProfile,
}) => {
  const t = translations[lang];
  const [editing, setEditing] = useState(false);
  const [displayName, setDisplayName] = useState(currentUser.displayName);
  const [bio, setBio] = useState(currentUser.bio || '');
  const [saving, setSaving] = useState(false);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !file.type.startsWith('image/')) return;
    setUploadingPhoto(true);
    try {
      const compressed = await compressImageFile(file, 256, 0.78);
      if (currentUser.isGuest) {
        onUpdateGuestProfile({ photoURL: compressed });
      } else {
        await updateDoc(doc(db, 'users', currentUser.uid), {
          photoURL: compressed,
          updatedAt: serverTimestamp(),
        });
      }
    } catch (error) {
      if (!currentUser.isGuest) {
        handleFirestoreError(error, OperationType.UPDATE, `users/${currentUser.uid}`);
      }
    } finally {
      setUploadingPhoto(false);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!displayName.trim() || saving) return;
    if (currentUser.isGuest) {
      onUpdateGuestProfile({
        displayName: displayName.trim().slice(0, 80),
        bio: bio.trim().slice(0, 200),
      });
      setEditing(false);
      return;
    }
    setSaving(true);
    try {
      await updateDoc(doc(db, 'users', currentUser.uid), {
        displayName: displayName.trim().slice(0, 80),
        bio: bio.trim().slice(0, 200),
        updatedAt: serverTimestamp(),
      });
      setEditing(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${currentUser.uid}`);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="h-full w-full overflow-y-auto bg-zinc-950 text-zinc-100">
      <div className="max-w-4xl mx-auto px-4 sm:px-8 py-6 sm:py-10 space-y-8 pb-20">
        {/* Profile Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 pb-8 border-b border-zinc-800/80">
          <div className="flex items-center gap-4 sm:gap-5">
            {/* Avatar with Change Photo Trigger */}
            <div className="relative shrink-0">
              {currentUser.photoURL ? (
                <img
                  src={currentUser.photoURL}
                  alt={currentUser.displayName}
                  referrerPolicy="no-referrer"
                  className="w-20 h-20 rounded-full object-cover border-2 border-amber-500"
                />
              ) : (
                <div className="w-20 h-20 rounded-full bg-amber-500 text-zinc-950 font-extrabold text-2xl flex items-center justify-center">
                  {currentUser.displayName.charAt(0).toUpperCase()}
                </div>
              )}

              <label
                title={lang === 'ku' ? 'گۆڕینی وێنەی پرۆفایل' : 'Change profile picture'}
                className="absolute -bottom-1 -right-1 w-8 h-8 rounded-full bg-zinc-900 border border-zinc-700 text-amber-400 flex items-center justify-center hover:bg-zinc-800 cursor-pointer shadow-md"
              >
                <Camera className="w-4 h-4" />
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleAvatarChange}
                  disabled={uploadingPhoto}
                  className="hidden"
                />
              </label>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-display text-2xl font-bold text-white">
                  {currentUser.displayName}
                </h1>
                <VerifiedBadge followersCount={currentUser.followersCount} className="w-5 h-5" />
              </div>
              <p className="text-sm text-zinc-400">
                @{currentUser.username}
                {currentUser.age ? ` · تەمەن: ${currentUser.age}` : ''}
              </p>
              {currentUser.bio && (
                <p className="mt-2 text-sm text-zinc-200 max-w-md">{currentUser.bio}</p>
              )}
              <div className="mt-3 flex items-center gap-4 text-xs font-mono-tabular text-zinc-400">
                <span>
                  <strong className="text-white">
                    {formatFollowersCount(currentUser.followersCount)}
                  </strong>{' '}
                  {lang === 'ku' ? 'فۆڵۆوەر' : 'Followers'}
                </span>
                <span aria-hidden="true">·</span>
                <span>
                  <strong className="text-white">{friendsCount}</strong> {t.friendsTab}
                </span>
                <span aria-hidden="true">·</span>
                <span>
                  <strong className="text-white">{myPosts.length}</strong> {t.feedTab}
                </span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <label className="min-h-[42px] px-4 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs font-semibold text-amber-400 flex items-center gap-1.5 hover:bg-zinc-800 transition-colors cursor-pointer">
              <Camera className="w-3.5 h-3.5" />
              <span>
                {uploadingPhoto
                  ? '...'
                  : lang === 'ku'
                  ? 'گۆڕینی وێنە'
                  : 'Change Photo'}
              </span>
              <input
                type="file"
                accept="image/*"
                onChange={handleAvatarChange}
                disabled={uploadingPhoto}
                className="hidden"
              />
            </label>

            <a
              href="/kurdtick-website.zip"
              download="kurdtick-website.zip"
              className="min-h-[42px] px-4 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs font-semibold text-zinc-200 flex items-center gap-1.5 hover:bg-zinc-800 transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-amber-400" />
              <span>{lang === 'ku' ? 'داگرتنی فایل (.zip)' : 'Download (.zip)'}</span>
            </a>

            <button
              type="button"
              onClick={onToggleLang}
              className="min-h-[42px] px-4 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs font-semibold text-zinc-200 hover:bg-zinc-800 transition-colors cursor-pointer"
            >
              {lang === 'ku' ? 'English' : 'کوردی سۆرانی'}
            </button>
            <button
              type="button"
              onClick={() => setEditing((v) => !v)}
              className="min-h-[42px] px-4 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs font-semibold text-white hover:bg-zinc-800 transition-colors cursor-pointer"
            >
              {t.editProfile}
            </button>
            <button
              type="button"
              onClick={() => {
                if (currentUser.isGuest) {
                  onGuestSignOut();
                } else {
                  signOut(auth);
                }
              }}
              className="min-h-[42px] px-4 py-2 rounded-xl bg-red-500/10 border border-red-500/25 text-xs font-semibold text-red-300 flex items-center gap-1.5 hover:bg-red-500/20 transition-colors cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>{t.signOut}</span>
            </button>
          </div>
        </div>

        {/* Edit Profile Form */}
        {editing && (
          <form
            onSubmit={handleSave}
            className="p-6 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-4 max-w-lg"
          >
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                ناوی دیار
              </label>
              <input
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                maxLength={80}
                required
                className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                {t.bioLabel}
              </label>
              <textarea
                rows={2}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                maxLength={200}
                className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-500 resize-none"
              />
            </div>
            <div className="flex items-center gap-3">
              <button
                type="submit"
                disabled={saving}
                className="min-h-[42px] px-5 py-2 rounded-xl bg-amber-500 text-zinc-950 text-xs font-bold flex items-center gap-1.5 hover:bg-amber-400 cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>{t.save}</span>
              </button>
              <button
                type="button"
                onClick={() => setEditing(false)}
                className="min-h-[42px] px-4 py-2 rounded-xl bg-zinc-800 text-zinc-300 text-xs font-semibold hover:bg-zinc-700 cursor-pointer"
              >
                پاشگەزبوونەوە
              </button>
            </div>
          </form>
        )}

        {/* My Reels Grid */}
        <section className="space-y-4 pb-12">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-bold text-white">{t.myPosts}</h2>
            <button
              type="button"
              onClick={onOpenCreatePost}
              className="min-h-[40px] px-4 py-2 rounded-xl bg-amber-500 text-zinc-950 text-xs font-bold flex items-center gap-1.5 hover:bg-amber-400 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{t.createPost}</span>
            </button>
          </div>

          {myPosts.length === 0 ? (
            <div className="p-8 rounded-2xl bg-zinc-900/60 border border-zinc-800/80 text-center">
              <Film className="w-8 h-8 text-zinc-600 mx-auto mb-2" />
              <p className="text-sm text-zinc-400">
                {lang === 'ku' ? 'هێشتا هیچ پۆستێکت نییە.' : 'You have not published any reels yet.'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
              {myPosts.map((post) => (
                <div
                  key={post.id}
                  className="aspect-[9/16] rounded-xl overflow-hidden bg-zinc-900 border border-zinc-800 relative group"
                >
                  {post.mediaType === 'video' ? (
                    <video
                      src={post.mediaUrl}
                      muted
                      playsInline
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <img
                      src={post.mediaUrl}
                      alt={post.caption || 'Reel'}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  )}
                  <div className="absolute inset-x-0 bottom-0 p-2.5 bg-gradient-to-t from-black/85 to-transparent text-white">
                    <p className="text-xs line-clamp-2">{post.caption}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
};
